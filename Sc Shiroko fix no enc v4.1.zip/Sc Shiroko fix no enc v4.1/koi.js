/*
    Sc Shiroko-MD V4.1
    My Contact 0831-3983-0624
    
    Notes:
    Script ini jangan di jual !!!
   
*/

const fs = require('fs')
const chalk = require('chalk')
const moment = require('moment-timezone')

global.grup = 'https://whatsapp.com/channel/0029VaUuBJuAzNbrY4beuQ0C'
global.ig = '@vanitas_koi'
global.thumb = fs.readFileSync("./datakoi/image/thumb.jpg")
global.email = 'palsu8877@gmail.com'
global.region = 'indonesia'
//—————「 Set Nama Own & Bot 」—————//
global.ownername = 'センス'
global.domain = '' // isi pake link domain panel mu
global.apikey2 = '' // Isi apikey plta mu
global.capikey2 = '' // isi apikey ptlc mu
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location

global.owner = ['628313980624']

global.keyopenai = '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'
global.ibeng = 'Yl4h5x9wiA'

global.botname = 'Shiroko-MD'
global.packname = 'Sunaookami Shiroko'
global.author = `Date: ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}\nBot: 0856-0750-98806`
global.prefa = ['','!','.',',','🐤','🗿']
global.sessionName = 'Shiroko-MD'
global.sp = '⭔'
global.anticall = true

global.mess = {
    success: 'Done',
    admin: '❗Perintah Ini Hanya Bisa Digunakan Oleh Admin Group !',
    botAdmin: '❗Perintah Ini Hanya Bisa Digunakan Ketika Bot Menjadi Admin Group !',
    owner: '❗Perintah Ini Hanya Bisa Digunakan Oleh Owner !',
    group: '❗Perintah Ini Hanya Bisa Digunakan Di Group Chat !',
    private: '❗Perintah Ini Hanya Bisa Digunakan Di Private Chat !',
    bot: '🤖 Fitur Khusus Pengguna Nomor Bot !',
    wait: '⏳ Sedang Di Proses !',
    endLimit: '🕊️ Limit Harian Anda Telah Habis, Limit Akan Direset Setiap Jam 12 !\n\n🎯 *Premium Cuma 10k Permanen* 😋',
    error: '🚫 Fitur Sedang Error !',
    prem: '🚫 Fitur Khusus Premium!\n\n♨️ Buy Premium Cuma 10k Permanen',
}

global.limitawal = {
    premium: "Infinity",
    free: 100
}

global.multiplier = 1000

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})